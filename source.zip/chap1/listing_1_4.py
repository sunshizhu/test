    def __str__(self):
        return str(self.num)+"/"+str(self.den)
