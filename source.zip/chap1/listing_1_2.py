class Fraction:

    def __init__(self,top,bottom):

        self.num = top
        self.den = bottom

