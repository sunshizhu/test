class UnorderedList:
    def __init__(self):
        self.head = None
