class SkipList:
    def __init__(self):
        self.head = None
