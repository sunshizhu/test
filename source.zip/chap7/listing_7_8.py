class OrderedList(UnorderedList):
    def __init__(self):
        UnorderedList.__init__(self)
