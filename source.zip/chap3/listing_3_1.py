def listsum(l):
    sum = 0
    for i in l:
        sum = sum + i
    return sum    
