    def __setitem__(self,k,v):
        self.put(k,v)
