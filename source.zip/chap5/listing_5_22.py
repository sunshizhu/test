    def length(self):
        return self.size
        
    def __len__(self):
        return self.size
